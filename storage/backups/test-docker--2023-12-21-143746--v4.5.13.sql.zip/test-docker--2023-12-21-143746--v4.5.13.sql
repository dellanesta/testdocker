-- MariaDB dump 10.19  Distrib 10.5.21-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_dhoivwmgxctchlrumovsshesjvccguimjgzf` (`ownerId`),
  CONSTRAINT `fk_dhoivwmgxctchlrumovsshesjvccguimjgzf` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zooldwlntzfxsshsatbiqcevvnnaouiiddxc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hzwpixqvynbwvzjrscgpwmgnzfoevmxdgvmo` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_npmkpggwlimkpdcsnteimhqsyklkiizkssep` (`dateRead`),
  KEY `fk_vumvftcgqewfflhcvvfgxftrhvccavumetvn` (`pluginId`),
  CONSTRAINT `fk_rilevaabqzydxqydgjsofgnlvumjvbeivnbv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vumvftcgqewfflhcvvfgxftrhvccavumetvn` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yumwjzpdazsykkryamjwuhpkhixcqkiqkmwy` (`sessionId`,`volumeId`),
  KEY `idx_pktapzpojeshthczwbvveycbwweunqjqwclo` (`volumeId`),
  CONSTRAINT `fk_jkeooukoojhvjxhifffvgbwmfbgjpcmvayny` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgjusyrifnnvlgbqwofivbuttpkbgpwtyxyd` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT 0,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `processIfRootEmpty` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wqkgdzyrobyyhmvguepfwhrvgtnmazpnojcc` (`filename`,`folderId`),
  KEY `idx_xibosbbrffoclibketbziyzbemnrmljzktec` (`folderId`),
  KEY `idx_wpdcmtlfubyvhsaxpkxpnuciowutvjxlnych` (`volumeId`),
  KEY `fk_etzajuqiojqxzwpqbethiazlhkiukwhknxtg` (`uploaderId`),
  CONSTRAINT `fk_aygfguzkdflcctpsvilfpnsvusvbfdasecuk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_etzajuqiojqxzwpqbethiazlhkiukwhknxtg` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hnxcztcxtmewnowdbtwsvoxoyakwxjznuedt` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rqjnrphupvfoecpsfvlseqqpujgjkdwcnbbt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lzmuroszddpmqanzmitbxkyxuuazfovxovql` (`groupId`),
  KEY `fk_hxwgjmoafghdzjwlecovhnrkcnbyhlztjehq` (`parentId`),
  CONSTRAINT `fk_hxwgjmoafghdzjwlecovhnrkcnbyhlztjehq` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_jabtscvxtdskynojitqjqmjhlmqagnlgnpso` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zfhbiiftegcdypvyyklmugotflurjiiwioec` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qhjbnfxuqktjcdyompapnmoboqnphgxagoni` (`name`),
  KEY `idx_qrsxjdxfblhyaomzvrzndmgesiczhcefwdqi` (`handle`),
  KEY `idx_esczhivmjqkjtarkyrczbrzyocslngzprnet` (`structureId`),
  KEY `idx_sxytkunnjzdbdbxyufugwtxhfcejeualppwy` (`fieldLayoutId`),
  KEY `idx_giytabosnybaconszdsuacjkwwbxoifucupk` (`dateDeleted`),
  CONSTRAINT `fk_zdvirnztsupwurjovjfoiyrhepzwrdusgxsl` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zohwdfqsgxjaudipvsiwngjpczomtemqspdx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uteoxmndjmznjuseduwzwnrgqhpswhhckcrd` (`groupId`,`siteId`),
  KEY `idx_vqcnrpdcvjheqehjdekvvizhqrrhaerxzbfl` (`siteId`),
  CONSTRAINT `fk_jdecpqdpcvmtoidudpjbsatjnadlyimxuphv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rqhhgmhobklqodsjgwqnqjpbeenutblsjwcz` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_twdgrafdhqyfoxzetrlohqjrpokyizfvwbvt` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_tyglorniuoctpvqytbtkdrzmfrqzpppshocg` (`siteId`),
  KEY `fk_juiaiogzmaftkymikbsdoryknkgixjopegjc` (`userId`),
  CONSTRAINT `fk_juiaiogzmaftkymikbsdoryknkgixjopegjc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tghnoiyublcthnyphtqnodsyxcxeiqgusucg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tyglorniuoctpvqytbtkdrzmfrqzpppshocg` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_bguzoalojctcgqtimcidbdbdanyuirfaxgvk` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_rbathtzvzxhgfopebubnkfxjkjnmsydgmzti` (`siteId`),
  KEY `fk_vsbjzoxlnyymsgzoxsesgmkuvlrsfynvklxa` (`fieldId`),
  KEY `fk_gopruhguxcqmcgzhggnohcecvtwkclrlkjlt` (`userId`),
  CONSTRAINT `fk_gopruhguxcqmcgzhggnohcecvtwkclrlkjlt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_rbathtzvzxhgfopebubnkfxjkjnmsydgmzti` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vsbjzoxlnyymsgzoxsesgmkuvlrsfynvklxa` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xvmepojtstkvcuzesoypktzuyynfvarqdbnr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_testo_cijgavbq` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hxpgafwaecyehjajlhqiemevjfdlajmqqimr` (`elementId`,`siteId`),
  KEY `idx_iihqffvmbkrlzuljinpksddtcuctyfomdije` (`siteId`),
  KEY `idx_qqmsfnwhdysbraxkrpxleqbiqgczjhfehqqr` (`title`),
  CONSTRAINT `fk_kuhuawnpvrfjxbrndthgamaajzcrsohmdoly` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uxpjazfudarhwxshvtfoqepnoumcteyeigxh` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_hhryrlwybeqvxxwwbolvcylcenopvwmifphl` (`userId`),
  CONSTRAINT `fk_hhryrlwybeqvxxwwbolvcylcenopvwmifphl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fdzotqlmmwuthkmxenyircbdkrbnckcbuoqu` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_rtodvijdkvesynstervlqyrqfwlwjpmojweq` (`creatorId`,`provisional`),
  KEY `idx_sptmnbrbysqwirfqejnrbvqxcpptiatpsxka` (`saved`),
  KEY `fk_ecmqfemfwdcdlkiyuftogdldtecafbbwebcs` (`canonicalId`),
  CONSTRAINT `fk_ecmqfemfwdcdlkiyuftogdldtecafbbwebcs` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_icenuuypljsudhkurutecinvkxhgkqjdyjzi` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elementactivity` (
  `elementId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `draftId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_ribhdvnuviseqrazqzvunyegmvyhualmdlvr` (`elementId`,`timestamp`,`userId`),
  KEY `fk_nyrfmslvvccvvqsfzbhgpatgmuefwklglcdk` (`userId`),
  KEY `fk_xzokkveinulyowxtmfkvijbcltwkqmnqubfo` (`siteId`),
  KEY `fk_ktqaympzbxrrreysnudfeamgyhahnvnmsdkd` (`draftId`),
  CONSTRAINT `fk_cxivqqfbmpsrkklndehbfgsuaxunoopbadwq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ktqaympzbxrrreysnudfeamgyhahnvnmsdkd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nyrfmslvvccvvqsfzbhgpatgmuefwklglcdk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzokkveinulyowxtmfkvijbcltwkqmnqubfo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rxjnbynclmungjduxwwvspwdmqpysktumvxq` (`dateDeleted`),
  KEY `idx_gdaglpsdqhncfcjjlsvfdpkevdfesgfldixu` (`fieldLayoutId`),
  KEY `idx_domcoerojymzkuakjfyxddixmdyxixseeglq` (`type`),
  KEY `idx_wdazrysdiairohxolrwskurvogtozokkxtgs` (`enabled`),
  KEY `idx_oxqrwjylffqgtogsyuntzkgjsytkomzaztil` (`canonicalId`),
  KEY `idx_jjfkcpgihifpelskpyxpmpxouugrnquerpst` (`archived`,`dateCreated`),
  KEY `idx_sufpvspkfyebtbypukqerkspozvvloadympe` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_rzpjzeflbpfnwrbjxobaihsiuhyfjagjtiho` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ynbsfsmvqefgqlklcsmbgiqzhgdrmexdcrea` (`draftId`),
  KEY `fk_twhutcuelvmualecvpsvptxfgvswzdawxaeu` (`revisionId`),
  CONSTRAINT `fk_hvlmmjglsrxartlkeiuupqnuahlrtinbvkhu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_twhutcuelvmualecvpsvptxfgvswzdawxaeu` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_whrmdfpcjoscpxmfclrkgsymigampejrpsmu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ynbsfsmvqefgqlklcsmbgiqzhgdrmexdcrea` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xswykgcnayfrdnzuoapnxnmwqiykknvsjxuj` (`elementId`,`siteId`),
  KEY `idx_mckzmxuxezawxakaxgpoxljcytchhbsiidmx` (`siteId`),
  KEY `idx_cimzfnahaelkzgkqvzeshasivrkynqvjbqks` (`slug`,`siteId`),
  KEY `idx_mjmkojjcwcypobkpuejrzpuomocpelmsrmbd` (`enabled`),
  KEY `idx_ejlrnjlmcufyclbjvdrlyinivwbbljtlifcx` (`uri`,`siteId`),
  CONSTRAINT `fk_bhbissshdbxnqzmxwuxuoxgnjtybojcrnnmb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sjoxkgvcyrnuwxbrrizcfejtcbvrthhpjwyk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wmtkpgsujitcoglyudrufnlorkjihhvetazz` (`postDate`),
  KEY `idx_wqeiututmmnemqqffylkoomdgxgnqhycrnek` (`expiryDate`),
  KEY `idx_vpobofvmqtfhaespdwzgvlwcrvrynnksxuaq` (`authorId`),
  KEY `idx_erupoqzaqovemwzikydieodpmslulalwfeob` (`sectionId`),
  KEY `idx_ooayeaeybrblumchtxpmcqkpuiigacmqibpm` (`typeId`),
  KEY `fk_jgtrelajhyjqwcbpayzufmfnonmkgkltyeio` (`parentId`),
  CONSTRAINT `fk_jgtrelajhyjqwcbpayzufmfnonmkgkltyeio` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_krqphdwoqvycsmttjxapnafubfmoaedhyohv` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kyqnxzcjwaxzntnmnjbxbakiihpmvabyehjz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sohuqcvgixxibzkbolmzmsprbofjmicxyxuc` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uzpjlqaekmeaxgexxobvegxydaiscxyflqrl` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text DEFAULT NULL,
  `showStatusField` tinyint(1) DEFAULT 1,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_crpvhhznswauciuwpuglgugmvpzzmjjldsxb` (`name`,`sectionId`),
  KEY `idx_hujwllofswwivnsrfhxgxsaaokkhxwbefyhl` (`handle`,`sectionId`),
  KEY `idx_cimfczkttkivmrdbrsdxyzeijqrsimawlluo` (`sectionId`),
  KEY `idx_wvshhdhhjqdwtlkpuyzwbffvvhdzucfiwzmc` (`fieldLayoutId`),
  KEY `idx_ekyolgyytcriscjrkcqaqfzkudgqzmtbeyhf` (`dateDeleted`),
  CONSTRAINT `fk_oqctjdcehafsizuehtquqnucslfahxxxtytu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_viyiruqrgwlarcndkbjvvplnzavtafmirhwt` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feedme_feeds`
--

DROP TABLE IF EXISTS `feedme_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedme_feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `feedUrl` text NOT NULL,
  `feedType` varchar(255) DEFAULT NULL,
  `primaryElement` varchar(255) DEFAULT NULL,
  `elementType` varchar(255) NOT NULL,
  `elementGroup` text DEFAULT NULL,
  `siteId` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `singleton` tinyint(1) NOT NULL DEFAULT 0,
  `duplicateHandle` text DEFAULT NULL,
  `updateSearchIndexes` tinyint(1) NOT NULL DEFAULT 1,
  `paginationNode` text DEFAULT NULL,
  `fieldMapping` text DEFAULT NULL,
  `fieldUnique` text DEFAULT NULL,
  `passkey` varchar(255) NOT NULL,
  `backup` tinyint(1) NOT NULL DEFAULT 0,
  `setEmptyValues` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mgtyscnrdrgcxloisjsqjguyyffcdqzminvc` (`name`),
  KEY `idx_lnvrhrlcacjkzwcepgwzlfzcfgfwyoesvapn` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_snqiztockufcuuhwjjutvremkwafannryexz` (`layoutId`,`fieldId`),
  KEY `idx_gnctdxfjckhwbdmpihtpzfusptikxvqjwuio` (`sortOrder`),
  KEY `idx_vpzdbllbscvcsdeggbcnaabjnrwenovzxkxh` (`tabId`),
  KEY `idx_molwqvbytjplhrprhemlzvzkdinxvazdezgs` (`fieldId`),
  CONSTRAINT `fk_axpvetrlxpjhjoroywtohkatojdcjmjircuz` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ovwofxtuqdhrxnogsitzuuxnfgfgzfnyqdek` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xtlpntotpubapvpprffopjqmjbwmgnvbwmbx` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wpdzckqxwqxirtrsfdusqejjbqyxptykfkfc` (`dateDeleted`),
  KEY `idx_deosoakqbwxmupttdkoliltcflaycgkeanlq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qlshpqgrwwclwqvaqbqhswlsmrbzxdcgmijt` (`sortOrder`),
  KEY `idx_ebpnxnxlxrjzinsruyggdkzjckkbutymktxz` (`layoutId`),
  CONSTRAINT `fk_trpvkheebynsnrhrxsvefaqynbieraizhuyg` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bfyjxemmmbqymgfuqxksagrrucrowfvctkwl` (`handle`,`context`),
  KEY `idx_ecopulfndueatfcrdcfocxpubjifgxaybkqy` (`groupId`),
  KEY `idx_sjpowvecldnybvafafnkyvgglllencgwvjvi` (`context`),
  CONSTRAINT `fk_lpxbfraqkhcueekcaveihqfhmnijiswlcbtu` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ncyecbrtsbpkvsivfhzgpptajhlfatedigsf` (`name`),
  KEY `idx_skwvfnnmybjkpiuanznvnfzvmccispzivucd` (`handle`),
  KEY `idx_kmfstdqxinobwroezitpjvbocnquyphmqriu` (`fieldLayoutId`),
  KEY `idx_pqwrsibcrlciiznzvsbclxlhdmhfjayjwwyz` (`sortOrder`),
  CONSTRAINT `fk_nnoduyjrqqkdlekhrqxkqnacomsxujlggdwk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pctfoigvinmbemzzseiimtionigsiqogonfb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uahkigaulvzitdjgxtmoyafoqqnbaorleqxp` (`accessToken`),
  UNIQUE KEY `idx_ptflddacdoophhxnutppwjckenscumpufqxx` (`name`),
  KEY `fk_hfaohtbqptowbjmcuwqiaysrlqbjxmdgsivq` (`schemaId`),
  CONSTRAINT `fk_hfaohtbqptowbjmcuwqiaysrlqbjxmdgsivq` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_onulsyvgmzbvkrhcofcmhmbmlrbuukembkvb` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT 1,
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ljvkvyyouisgpwhgropwubwnrmbucjnzrrpc` (`name`),
  KEY `idx_dxdctbvuxoozujdvymvywqoxrihxkzpxcvlt` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_hupsdfiafqfisqkryxzxbdrrmfozynmwsskg` (`primaryOwnerId`),
  KEY `idx_rwyfapbmhcoaufsynswkjepqmvcmekegfhdj` (`fieldId`),
  KEY `idx_naxgvqroudxgcbqhnwucfqalkihpdiotydbn` (`typeId`),
  CONSTRAINT `fk_abchvdwmjxdfabvzklhtyjxdaoswnflhlbkb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mcphsrfgjienmbhstypjubqkfbetpflrsbfk` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nbjcevpenowyodtrdftnjhcvshkgtodnulgd` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vpyydvlkhuyvlerfijrcvpgbrybmsyzyikfa` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_wcutwysnqcgomurakfffhccpbtpdnyfgomjq` (`ownerId`),
  CONSTRAINT `fk_jjagreiavsffuzyrgbymfgfaswkdygdxgpgh` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wcutwysnqcgomurakfffhccpbtpdnyfgomjq` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qyglthejnzcahlkjglzahxvgzpvyudcmjnrc` (`name`,`fieldId`),
  KEY `idx_ncabojehcyijsuaqbimcebruyjtovyvxrbzv` (`handle`,`fieldId`),
  KEY `idx_fhwsfjfxnpuodyjsegfoangupicdkovdpezb` (`fieldId`),
  KEY `idx_vprxhjecynriosomnytcoxjqgronmzocxeau` (`fieldLayoutId`),
  CONSTRAINT `fk_kozcwtodaqujtjguhubobryiloycykrhflhb` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qvfussthnxaisykirmchzcsctervupmfmyod` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_matrix`
--

DROP TABLE IF EXISTS `matrixcontent_matrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_matrix` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_blocco_testo_mnpawajh` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qcstvsgijovzkywowkdjpjeqmzvngbanpwyz` (`elementId`,`siteId`),
  KEY `fk_wbnmipxoulafjuajsqkqdbemfzjylrkwthfp` (`siteId`),
  CONSTRAINT `fk_pkowfmvkompcuxamljqrdzzmtjxeciiiwoiu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wbnmipxoulafjuajsqkqdbemfzjylrkwthfp` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_csuvnolcrqidjyoinkltuucrwuavftjkrnzq` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kojunnlysagfyxrgvknwvftuhzwqtxkqrvfk` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_orysasmgcfvopudeadjtdgoynpquftropqge` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_dbwflosyyvtxyxhhreehuzkabjzehapdqgbm` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_huceymwwvqqswxhhneonvxmixswhgferirvs` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_flfaexztqyoxqewdkmipiveefdquwmoljtfw` (`sourceId`),
  KEY `idx_ekidasiakfowntapemhxakbbviqbcjtyzcvs` (`targetId`),
  KEY `idx_ttslkgeudgibaomxyintymisxababnmswfob` (`sourceSiteId`),
  CONSTRAINT `fk_aiuvpikprmjjhphngjtaxixckowznxsnuwwu` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jflwpkymhlszhoohtoawpfhcukhnisrmrwwl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yjnzqfuzbuvegmanpnmfpfgtibgatrjbnivu` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_klxjorkrwsusrpxiajaxmwafifmihkxeauck` (`canonicalId`,`num`),
  KEY `fk_qmtvjynmqttdaftjpzhmxkgzpdvlcpqgnrnk` (`creatorId`),
  CONSTRAINT `fk_qmtvjynmqttdaftjpzhmxkgzpdvlcpqgnrnk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tiegtkwjbavmklsmhmotevnqoyjcoluumepp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_nforkzvnurrdkbldkiqhbscfdbxzappnisxu` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_upthatkwcvcpaoxmbznyuqakvneicwjvmnpz` (`handle`),
  KEY `idx_nafrxctrhzwzzvdrhimugozskwrmknqjambv` (`name`),
  KEY `idx_dvkywbdpbpgnsnkldxxkwlwkbzsmtoinnnou` (`structureId`),
  KEY `idx_yvvgclzrludhpeyoxqeawszuayjhtehwlaup` (`dateDeleted`),
  CONSTRAINT `fk_lvczxycteqqzpkvogmtsgpwsaqvasaqseurk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ncjzzsxwfkfyofuivsyodoxoonreobcbemnv` (`sectionId`,`siteId`),
  KEY `idx_kpeatcgekoxelapyqjiyaicyvcdmrlrfazex` (`siteId`),
  CONSTRAINT `fk_feyvabudhvdchnqxujvmfnagkpfoidpoglzd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uwxpxlwuqklnnwupgqmiascktqjtcijyqcoq` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dqrdfinurppyuwuilqlrwxtqdvddujzvekrv` (`uid`),
  KEY `idx_ykibhtambsfstzvhpujcsmuiaxuqgffqcoin` (`token`),
  KEY `idx_ggrhjjnjzbjrpqdgkavbgmuxvrpshtnwochl` (`dateUpdated`),
  KEY `idx_jhxxtzrzicjmuyefkxenozzolfowzmqngczh` (`userId`),
  CONSTRAINT `fk_pvagzhzveziywslrbjqnnimhuplgitfevupq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vzowknqvvhilfbqbygjdvmpgmizztbdrdxpo` (`userId`,`message`),
  CONSTRAINT `fk_qznalsyshwvsguydrkhyfrvyxwwbrignxcuu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_birxvthmfjqqfwjxrljnfyhmnbtdhlejzccr` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_moevsmkygkgptzfpnqausdbutnllakogcqcm` (`dateDeleted`),
  KEY `idx_gsmaybzkzqujswdlynsbddurrgufcbjlseax` (`handle`),
  KEY `idx_ergswlmywjblhzbbqqcwkvsjbubgksupmobh` (`sortOrder`),
  KEY `fk_yaefcbrcaqbhvjpjsgvvdkejyfrurrynkmgi` (`groupId`),
  CONSTRAINT `fk_yaefcbrcaqbhvjpjsgvvdkejyfrurrynkmgi` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_meuulgirtoeojcsemoztiedjcyeevfmevhiz` (`structureId`,`elementId`),
  KEY `idx_denukylwcodtlzeixwcbzrvzfvmbboewwano` (`root`),
  KEY `idx_yxtcbvigxxhwvmxkndlhvtzjjdlqdvayohqd` (`lft`),
  KEY `idx_cwnieajsiwnsbrfkasnimyjzvfeklosjhkvh` (`rgt`),
  KEY `idx_ljfnrehubxvxlndjarzawgwzmwepxkuwkfff` (`level`),
  KEY `idx_evzjlkzgkoagjlgflrjgxnvoocxdikjqgndh` (`elementId`),
  CONSTRAINT `fk_ctgfbzomayplokxqbbiljewlaezmpwglplof` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zeaqizkicjtdysfobggckdlxezgykpngczco` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mmmjpypxlvknhanqgxylgjatpmlpbkxtedwu` (`key`,`language`),
  KEY `idx_fjpmljspwoekrniitqbaqelnbqmuofbdsjvn` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uqklyvgejmupzkjcmjhcpmobyonajgyhxwpf` (`name`),
  KEY `idx_pvvyymcmvosguqdairhsjhyshhtpznwwlatq` (`handle`),
  KEY `idx_fjdpjdkcpixvjpwefbryhahuwthxlvctgwpk` (`dateDeleted`),
  KEY `fk_hhtmmxwmxbozkxstbclozxniykfavkzmngjs` (`fieldLayoutId`),
  CONSTRAINT `fk_hhtmmxwmxbozkxstbclozxniykfavkzmngjs` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qoqscagljtjhkrxxduumgpdtdzoxdudztfjd` (`groupId`),
  CONSTRAINT `fk_wblkqtwqkkimftqpzrzjrfkcdumuhxmnthis` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wlechlxmbojrppopyecilplyxndfrwfokwgk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lvythgptgxdtavbrnmjgwvptddrplwmhlwsr` (`token`),
  KEY `idx_gdgzabvrsgjmjoodncijozcsbmwesybyvwih` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wfmtzhmragojkimwbymvymcctvasydkkvpui` (`handle`),
  KEY `idx_rtakmdnuxxryhwxcdfoxxhxcrdiyndybozcr` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cmzwbesgrxaoezryrfzjybzhtvatldjmpxjg` (`groupId`,`userId`),
  KEY `idx_caotpqacydikgondxezzaxhoweyqrlvphyhc` (`userId`),
  CONSTRAINT `fk_oyzthmdncnvqpkcmevtobygehmguiadmpuow` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_swtvhrxzepfatdwhvntoardhujduqlrzvice` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qslsdohmwtidopyzhmjoggzdpgnusdrjzzeu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eksbqlclkqgosyryhdtgtcrghxpjqpodjedp` (`permissionId`,`groupId`),
  KEY `idx_cvttzzzsfhzgjswvtzqmarqmjxczwvyegjbt` (`groupId`),
  CONSTRAINT `fk_bfidufmyhsgxpcriprfzknqlppzxwaomxkyl` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hvlvdtocpsbdajyriwldqrgelzrjkzlinnce` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmfwcywwzzroazywxukbzmszqsrffuwgyvku` (`permissionId`,`userId`),
  KEY `idx_mpfiaerxsnkighpvdpzumjtzxwgyrhhyowqt` (`userId`),
  CONSTRAINT `fk_dcglxhpavlgldowgeaohlwghdafspmfbrvmk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dtnhowvqemsgarcxnthrdvvwfquxhevsiqzn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_baimqeibrfvgqsgudrmhqcmyrphsbxgjfaop` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gxsrxbdvgxrfcbovyfvioxlnzmzzgesgfjsd` (`active`),
  KEY `idx_qmvmltstltodjnapmccxuflvvkowvquuwwbh` (`locked`),
  KEY `idx_uyoiwcevryfatltpdxnpgakgnmnhecmrcvob` (`pending`),
  KEY `idx_yrvmbaatkejpptojfswftacxenjvtpkhmfir` (`suspended`),
  KEY `idx_pphhepfbsrnnmpllebqxtvrsbpypywznogxm` (`verificationCode`),
  KEY `idx_hsxnhhqdayolvaovvrgizhzdmnyrruggedix` (`email`),
  KEY `idx_ltaoeiyaywcoxjdyxbinsrqkuagarxlknpuk` (`username`),
  KEY `fk_sfuskvllnminudfbofejyuedeailnmpssvjo` (`photoId`),
  CONSTRAINT `fk_rtkinqsxizzvjddzycgvnmmgycotqhjjsuqh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sfuskvllnminudfbofejyuedeailnmpssvjo` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gazzpixbuxhdpnchaiifetmyadpssmtiqldu` (`name`,`parentId`,`volumeId`),
  KEY `idx_wokikwovmsqqofjxyhydpmvvozffumnltuea` (`parentId`),
  KEY `idx_chzbtgguppznfcidovrathzmfghocsjpizhn` (`volumeId`),
  CONSTRAINT `fk_nwwapgaqqkiztgksuzhdtneycpflltxxzies` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xyikoceacogggklmzlzjznmhamfxqyrxdvop` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cmdxrilvndilnjualhcbtguxtsbgbvqugayf` (`name`),
  KEY `idx_jiczjwfjsonttgqinayesftafslorhbeetyf` (`handle`),
  KEY `idx_tiltnsustwsksvajmskufuforaebidklzgwz` (`fieldLayoutId`),
  KEY `idx_mkzrogxmionexztwmmulbdszntjxkyhhxgvs` (`dateDeleted`),
  CONSTRAINT `fk_qbilhjicslmgfwnoywbjczmjizbjkjsnizqk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_honmyatahrkroqnzdpyocgomzuopklcsfwjk` (`userId`),
  CONSTRAINT `fk_apjvetgoudansyvqrazxbuwmbogkwntbyufm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-21 14:37:46
-- MariaDB dump 10.19  Distrib 10.5.21-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.4.31-MariaDB-1:10.4.31+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (3,1,'postDate','2023-12-21 14:33:31',0,2),(3,1,'slug','2023-12-21 14:33:18',0,2),(3,1,'title','2023-12-21 14:33:18',0,2),(3,1,'uri','2023-12-21 14:33:18',0,2);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (3,1,1,'2023-12-21 14:33:21',0,2),(3,1,3,'2023-12-21 14:33:29',0,2);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,'Homepage','2023-12-21 14:02:10','2023-12-21 14:02:10','31de7459-0ab7-40ef-84de-b7b470cdef7d',NULL),(2,2,1,NULL,'2023-12-21 14:02:10','2023-12-21 14:02:10','42650bcb-2d8c-4fa5-ac0b-b67cc3b9f773',NULL),(3,3,1,'Test entry','2023-12-21 14:33:09','2023-12-21 14:33:31','c9b1359e-138b-458e-9c33-07297cee6eff','<p>fewgfdbgd d tg th</p>');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (3,2,1,NULL,'save','2023-12-21 14:33:31');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,NULL,'e85e0b36-828f-4555-ad01-f1830f4e71d9'),(2,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,NULL,'31bf588e-ef8a-4bdd-96e9-bc0862fadcb7'),(3,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2023-12-21 14:33:09','2023-12-21 14:33:31',NULL,NULL,'f54820c7-9579-4c0a-85b7-a388b5d3bae1'),(4,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2023-12-21 14:33:25','2023-12-21 14:33:25',NULL,'2023-12-21 14:33:27','a5a33ddf-8da3-40e6-b338-28b05b7143c3'),(5,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2023-12-21 14:33:27','2023-12-21 14:33:27',NULL,'2023-12-21 14:33:29','a0ca1b64-c33c-4eb4-b623-69f7d94ea176'),(6,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2023-12-21 14:33:29','2023-12-21 14:33:29',NULL,NULL,'62bc348e-fefb-4cee-a8af-d7271616d13c');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,'homepage','__home__',1,'2023-12-21 14:02:10','2023-12-21 14:02:10','ef078b3d-595a-422a-ad99-ac4004bfa2d1'),(2,2,1,NULL,NULL,1,'2023-12-21 14:02:10','2023-12-21 14:02:10','e7788fb9-cd80-46d1-8918-0b82c03a0233'),(3,3,1,'test-entry','test/test-entry',1,'2023-12-21 14:33:09','2023-12-21 14:33:18','fe49b1b5-805c-416a-96e1-71ae57b6e385'),(4,4,1,NULL,NULL,1,'2023-12-21 14:33:25','2023-12-21 14:33:25','c7f07ff9-02c4-4a60-a6eb-99ad6cceec6a'),(5,5,1,NULL,NULL,1,'2023-12-21 14:33:27','2023-12-21 14:33:27','33e197cc-01ab-479e-b9f2-fd6a18cfabae'),(6,6,1,NULL,NULL,1,'2023-12-21 14:33:29','2023-12-21 14:33:29','7a0cdbf9-1473-49a5-b805-1578a3ac10f9');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (1,3,NULL,3,NULL,'2023-12-21 14:02:00',NULL,NULL,'2023-12-21 14:02:10','2023-12-21 14:02:10'),(3,2,NULL,2,2,'2023-12-21 14:33:00',NULL,NULL,'2023-12-21 14:33:09','2023-12-21 14:33:31');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,1,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'943a0c4d-6ca1-44ff-9a54-21837fcee488'),(2,2,2,'Default','default',1,'site',NULL,NULL,'site',NULL,1,1,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'adb5b625-1b31-4da6-81ae-c8f553cdcd9b'),(3,3,3,'Homepage','homepage',0,'site',NULL,'{section.name|raw}','site',NULL,1,1,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'cb3eb1f1-99e6-4d58-9e62-aae04d9497f5');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `feedme_feeds`
--

LOCK TABLES `feedme_feeds` WRITE;
/*!40000 ALTER TABLE `feedme_feeds` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `feedme_feeds` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'684cc56c-13ac-45b3-807a-2077cfac261a');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (12,3,12,1,0,1,'2023-12-21 14:02:10','2023-12-21 14:02:10','1c7acd08-4f3b-4126-a509-c0ca8f9477d7'),(13,4,13,4,0,0,'2023-12-21 14:32:43','2023-12-21 14:32:43','59cbaed4-df3d-49ec-9a2a-31f73550032e'),(14,4,13,5,0,1,'2023-12-21 14:32:43','2023-12-21 14:32:43','49b7b453-97bd-4531-a262-0c6bf946ea24'),(15,2,14,1,0,1,'2023-12-21 14:32:56','2023-12-21 14:32:56','206128c7-ed67-4aec-815b-2972923fe85a'),(16,2,14,2,0,2,'2023-12-21 14:32:56','2023-12-21 14:32:56','47557358-4c9e-4f56-8673-024e2925a469'),(17,2,14,3,0,3,'2023-12-21 14:32:56','2023-12-21 14:32:56','d5d74650-f330-43c3-a21e-4d09c9666f73');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'4d8be229-007f-4089-829d-4209a3df545a'),(2,'craft\\elements\\Entry','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'8472f6c2-8ef8-4eeb-a888-b9d727448188'),(3,'craft\\elements\\Entry','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'d1a50498-6817-4451-b72d-f6b631649fe5'),(4,'craft\\elements\\MatrixBlock','2023-12-21 14:32:43','2023-12-21 14:32:43',NULL,'f49e7efc-e7fe-416f-ab1c-eb2765b940d0');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (8,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\TitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"94b762c6-5616-4bf9-940f-698d64533a52\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-12-21 14:02:10','2023-12-21 14:02:10','b54c64eb-29bf-43ea-a2bf-49350eda4984'),(12,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"774eb169-012f-4ac0-bbee-2d0f2201c788\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"2f78b467-863e-487d-8853-7234e1813155\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f095057b-12b7-426e-bba9-77a4e6e2c1ce\"}]',1,'2023-12-21 14:02:10','2023-12-21 14:02:10','b5d5ed21-3874-4a9f-b997-2238762bba31'),(13,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"070ae3fe-6079-479d-b5f3-b765c7a20f69\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"16f54560-82dd-48ec-80f4-1288baf410fa\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"5e758ecc-ab92-41be-97a4-563e1adf764f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"497a8ec3-9f9a-4947-a0b1-b9404c1c59f3\"}]',1,'2023-12-21 14:32:43','2023-12-21 14:32:43','4f5ce121-9e6f-47c7-9786-c0070f0e4f96'),(14,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"inputType\":null,\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"af51a2e8-5c3e-445d-9586-f5b84e10008b\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"f3345ed9-b054-4fec-8049-2354617c3625\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f095057b-12b7-426e-bba9-77a4e6e2c1ce\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"b18eeb9f-e17e-44f4-9af2-a0b58af5e2cc\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"218ba258-0fdf-4523-aacc-3b77f78e0b41\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"b3ebea84-071a-4dc9-b0da-f90a9121d9f3\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e84f8add-70a4-4227-835b-be62710af7e2\"}]',1,'2023-12-21 14:32:56','2023-12-21 14:32:56','28ed5f27-eb51-4787-9715-a38beb79aa57');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,1,'Testo','testo','global','cijgavbq',NULL,0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":null,\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-12-21 14:02:10','2023-12-21 14:02:10','f095057b-12b7-426e-bba9-77a4e6e2c1ce'),(2,1,'Related','related','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"selectionLabel\":null,\"showSiteMenu\":false,\"sources\":[\"section:8cf230db-3044-4cb7-aeb7-ed3578d3485d\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-12-21 14:02:10','2023-12-21 14:02:10','218ba258-0fdf-4523-aacc-3b77f78e0b41'),(3,1,'Matrix','matrix','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_matrix}}\",\"maxBlocks\":null,\"minBlocks\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\"}','2023-12-21 14:32:43','2023-12-21 14:32:43','e84f8add-70a4-4227-835b-be62710af7e2'),(4,NULL,'testo','testo','matrixBlockType:e679f241-0434-4caa-aab9-a8cb07cc0a72','mnpawajh',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-12-21 14:32:43','2023-12-21 14:32:43','16f54560-82dd-48ec-80f4-1288baf410fa'),(5,NULL,'entry','entry','matrixBlockType:e679f241-0434-4caa-aab9-a8cb07cc0a72',NULL,NULL,0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-12-21 14:32:43','2023-12-21 14:32:43','497a8ec3-9f9a-4947-a0b1-b9404c1c59f3');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.5.13','4.5.3.0',0,'lvhjyirxbrtb','3@onsqebtend','2023-12-21 14:02:10','2023-12-21 14:32:57','36450b6b-a5ba-42fa-830a-0fe9208aaba5');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (4,3,3,1,0,'2023-12-21 14:33:25','2023-12-21 14:33:25'),(5,3,3,1,0,'2023-12-21 14:33:27','2023-12-21 14:33:27'),(6,3,3,1,NULL,'2023-12-21 14:33:29','2023-12-21 14:33:29');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (4,3,1),(5,3,1),(6,3,1);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,3,4,'Blocco','blocco',1,'2023-12-21 14:32:43','2023-12-21 14:32:43','e679f241-0434-4caa-aab9-a8cb07cc0a72');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_matrix`
--

LOCK TABLES `matrixcontent_matrix` WRITE;
/*!40000 ALTER TABLE `matrixcontent_matrix` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_matrix` VALUES (1,4,1,'2023-12-21 14:33:25','2023-12-21 14:33:25','a45d9cc4-5b00-407d-bf90-8725cb5f13ff',NULL),(2,5,1,'2023-12-21 14:33:27','2023-12-21 14:33:27','86120e5e-7532-4f4b-8b8c-54991ff8ac29','twretret'),(3,6,1,'2023-12-21 14:33:29','2023-12-21 14:33:29','9f46af24-0f74-46f5-acfa-1652237360d9','twretret');
/*!40000 ALTER TABLE `matrixcontent_matrix` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'plugin:feed-me','Install','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','efa8f6fc-1e7b-412d-aa48-5bbd20321545'),(2,'plugin:feed-me','m230123_152413_set_empty_values','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','1f0ba3e3-085d-4b23-ba10-0397fc1fb879'),(3,'plugin:redactor','m180430_204710_remove_old_plugins','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','c1720b61-ac2f-4dd8-8c4c-01e3a5de2b86'),(4,'plugin:redactor','Install','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','41394834-5d14-4167-bd35-3c0b05f44546'),(5,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','79e3387d-2c79-4726-a9d8-f3a2b4237ae5'),(6,'craft','Install','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','15ee2056-c23d-47b4-88a5-136fbb972fa5'),(7,'craft','m210121_145800_asset_indexing_changes','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','c75464e3-4ab2-47e3-8922-54e8e53b5c6f'),(8,'craft','m210624_222934_drop_deprecated_tables','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','616e6699-1270-4ed5-8359-c858e2d7612a'),(9,'craft','m210724_180756_rename_source_cols','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','38fcc848-72ca-49a1-bcf9-26e96df01321'),(10,'craft','m210809_124211_remove_superfluous_uids','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','b5150188-ae0b-4de5-bf57-b5811d9083ae'),(11,'craft','m210817_014201_universal_users','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','7771326a-46ca-495a-bc17-20044398aff7'),(12,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','bc0b8997-d4ca-45e4-ac08-3573e9a13bd5'),(13,'craft','m211115_135500_image_transformers','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','0ce48a72-a3b1-4bcb-814e-def48652ac58'),(14,'craft','m211201_131000_filesystems','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','84327841-ec58-47cd-921f-e4f0fefec762'),(15,'craft','m220103_043103_tab_conditions','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','c29bbf3b-f5ba-49a7-9ddf-9516bf7b9b65'),(16,'craft','m220104_003433_asset_alt_text','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','c7671ac1-b0f9-42a1-a27e-cde99b6bc2c1'),(17,'craft','m220123_213619_update_permissions','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','3df9f4dd-3682-48e3-a23b-7eb4bc7c341b'),(18,'craft','m220126_003432_addresses','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','d8f1853a-7fcc-4963-a63d-9289020b8237'),(19,'craft','m220209_095604_add_indexes','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','c2954077-d718-4dcb-addc-945dc69aa811'),(20,'craft','m220213_015220_matrixblocks_owners_table','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','bfecbbb2-c6e9-4bc3-9a06-28df9187e1a3'),(21,'craft','m220214_000000_truncate_sessions','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','87d18443-01d7-4911-8595-52eca7450910'),(22,'craft','m220222_122159_full_names','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','e9f57ae9-d854-4449-8235-bc69b057f361'),(23,'craft','m220223_180559_nullable_address_owner','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','e3c96909-6195-4262-b4d8-cf7cae1f6f0a'),(24,'craft','m220225_165000_transform_filesystems','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','1d68ab69-5971-4d0c-a728-a687647e1383'),(25,'craft','m220309_152006_rename_field_layout_elements','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','9669400f-3490-477f-898c-d4a15c2313a2'),(26,'craft','m220314_211928_field_layout_element_uids','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','8bf5a662-a33c-45f6-b4a7-c6a94d6413bc'),(27,'craft','m220316_123800_transform_fs_subpath','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','31fac31b-c9cf-4712-97ae-cf24ac847bf2'),(28,'craft','m220317_174250_release_all_jobs','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','2dcd3001-1157-41b2-bd58-ba72d5d38165'),(29,'craft','m220330_150000_add_site_gql_schema_components','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','e296bce4-495d-47b2-9660-91d80d91fb65'),(30,'craft','m220413_024536_site_enabled_string','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','b9f18d1a-7288-40a4-854d-a9574557c1e5'),(31,'craft','m221027_160703_add_image_transform_fill','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','26f0e2e1-1e5d-45bd-a039-7ab1fdb92547'),(32,'craft','m221028_130548_add_canonical_id_index','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','4e070049-5249-43c5-ac7a-d3f40764935d'),(33,'craft','m221118_003031_drop_element_fks','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','ce66ca01-c610-4d82-8e11-65be9b088d79'),(34,'craft','m230131_120713_asset_indexing_session_new_options','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','8ebe7422-8d58-4323-be24-11c936af993d'),(35,'craft','m230226_013114_drop_plugin_license_columns','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','ec49caee-5ab3-421c-9309-8f974c81bb43'),(36,'craft','m230531_123004_add_entry_type_show_status_field','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','42aa3ee5-324f-4df2-8f5a-3b73e287eabf'),(37,'craft','m230607_102049_add_entrytype_slug_translation_columns','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','10a4d904-c461-4d07-96a9-c16c9c1f462c'),(38,'craft','m230710_162700_element_activity','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','87c66e62-78c6-4dcc-baf0-f6cea67028c2'),(39,'craft','m230820_162023_fix_cache_id_type','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','eb3025da-c491-4b6e-83c6-1ca6ef5455b4'),(40,'craft','m230826_094050_fix_session_id_type','2023-12-21 14:02:11','2023-12-21 14:02:11','2023-12-21 14:02:11','715437f0-6979-4bca-86df-6337c1bae474');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'element-api','3.0.1.1','1.0.0','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','a5acacb7-afbf-4ca6-b882-2ddbffcaae54'),(2,'feed-me','5.3.0','5.1.0.0','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:15:41','a995d405-03b5-4084-9a6c-7109554f0e26'),(3,'redactor','3.0.4','2.3.0','2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:02:10','eb01ec07-6e64-4ea3-954e-dec46e49b9e6');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('dateModified','1703169176'),('email.fromEmail','\"michele@dellanesta.it\"'),('email.fromName','\"Test Docker\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elementCondition','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.autocapitalize','true'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.autocomplete','false'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.autocorrect','true'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.class','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.disabled','false'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.elementCondition','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.id','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.instructions','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.label','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.max','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.min','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.name','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.orientation','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.placeholder','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.readonly','false'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.requirable','false'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.size','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.step','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.tip','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.title','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.uid','\"94b762c6-5616-4bf9-940f-698d64533a52\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.userCondition','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.warning','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.elements.0.width','100'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.name','\"Content\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.uid','\"b54c64eb-29bf-43ea-a2bf-49350eda4984\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.fieldLayouts.4d8be229-007f-4089-829d-4209a3df545a.tabs.0.userCondition','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.handle','\"default\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.hasTitleField','true'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.name','\"Default\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.section','\"8cf230db-3044-4cb7-aeb7-ed3578d3485d\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.showStatusField','true'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.slugTranslationKeyFormat','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.slugTranslationMethod','\"site\"'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.sortOrder','1'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.titleFormat','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.titleTranslationKeyFormat','null'),('entryTypes.943a0c4d-6ca1-44ff-9a54-21837fcee488.titleTranslationMethod','\"site\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elementCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.autocapitalize','true'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.autocomplete','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.autocorrect','true'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.class','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.disabled','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.elementCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.id','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.inputType','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.instructions','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.label','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.max','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.min','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.name','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.orientation','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.placeholder','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.readonly','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.requirable','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.size','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.step','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.tip','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.title','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.uid','\"af51a2e8-5c3e-445d-9586-f5b84e10008b\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.userCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.warning','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.0.width','100'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.elementCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.fieldUid','\"f095057b-12b7-426e-bba9-77a4e6e2c1ce\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.instructions','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.label','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.required','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.tip','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.uid','\"f3345ed9-b054-4fec-8049-2354617c3625\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.userCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.warning','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.1.width','100'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.elementCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.fieldUid','\"218ba258-0fdf-4523-aacc-3b77f78e0b41\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.instructions','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.label','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.required','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.tip','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.uid','\"b18eeb9f-e17e-44f4-9af2-a0b58af5e2cc\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.userCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.warning','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.2.width','100'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.elementCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.fieldUid','\"e84f8add-70a4-4227-835b-be62710af7e2\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.instructions','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.label','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.required','false'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.tip','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.uid','\"b3ebea84-071a-4dc9-b0da-f90a9121d9f3\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.userCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.warning','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.elements.3.width','100'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.name','\"Content\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.uid','\"28ed5f27-eb51-4787-9715-a38beb79aa57\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.fieldLayouts.8472f6c2-8ef8-4eeb-a888-b9d727448188.tabs.0.userCondition','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.handle','\"default\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.hasTitleField','true'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.name','\"Default\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.section','\"04d63fa5-e717-48bf-b8f8-340293fffda5\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.showStatusField','true'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.slugTranslationKeyFormat','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.slugTranslationMethod','\"site\"'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.sortOrder','1'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.titleFormat','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.titleTranslationKeyFormat','null'),('entryTypes.adb5b625-1b31-4da6-81ae-c8f553cdcd9b.titleTranslationMethod','\"site\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elementCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.autocapitalize','true'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.autocomplete','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.autocorrect','true'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.class','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.disabled','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.elementCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.id','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.instructions','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.label','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.max','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.min','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.name','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.orientation','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.placeholder','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.readonly','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.requirable','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.size','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.step','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.tip','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.title','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.uid','\"774eb169-012f-4ac0-bbee-2d0f2201c788\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.userCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.warning','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.0.width','100'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.elementCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.fieldUid','\"f095057b-12b7-426e-bba9-77a4e6e2c1ce\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.instructions','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.label','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.required','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.tip','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.uid','\"2f78b467-863e-487d-8853-7234e1813155\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.userCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.warning','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.elements.1.width','100'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.name','\"Content\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.uid','\"b5d5ed21-3874-4a9f-b997-2238762bba31\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.fieldLayouts.d1a50498-6817-4451-b72d-f6b631649fe5.tabs.0.userCondition','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.handle','\"homepage\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.hasTitleField','false'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.name','\"Homepage\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.section','\"2453ab96-1f4f-4612-ab9b-d1e5203ac208\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.showStatusField','true'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.slugTranslationKeyFormat','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.slugTranslationMethod','\"site\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.sortOrder','1'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.titleFormat','\"{section.name|raw}\"'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.titleTranslationKeyFormat','null'),('entryTypes.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5.titleTranslationMethod','\"site\"'),('fieldGroups.684cc56c-13ac-45b3-807a-2077cfac261a.name','\"Common\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.columnSuffix','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.contentColumnType','\"string\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.fieldGroup','\"684cc56c-13ac-45b3-807a-2077cfac261a\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.handle','\"related\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.instructions','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.name','\"Related\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.searchable','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.allowSelfRelations','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.branchLimit','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.localizeRelations','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.maintainHierarchy','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.maxRelations','1'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.minRelations','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.selectionLabel','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.showSiteMenu','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.sources.0','\"section:8cf230db-3044-4cb7-aeb7-ed3578d3485d\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.targetSiteId','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.validateRelatedElements','false'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.settings.viewMode','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.translationKeyFormat','null'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.translationMethod','\"site\"'),('fields.218ba258-0fdf-4523-aacc-3b77f78e0b41.type','\"craft\\\\fields\\\\Entries\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.columnSuffix','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.contentColumnType','\"string\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.fieldGroup','\"684cc56c-13ac-45b3-807a-2077cfac261a\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.handle','\"matrix\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.instructions','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.name','\"Matrix\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.searchable','false'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.settings.contentTable','\"{{%matrixcontent_matrix}}\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.settings.maxBlocks','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.settings.minBlocks','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.settings.propagationKeyFormat','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.settings.propagationMethod','\"all\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.translationKeyFormat','null'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.translationMethod','\"site\"'),('fields.e84f8add-70a4-4227-835b-be62710af7e2.type','\"craft\\\\fields\\\\Matrix\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.columnSuffix','\"cijgavbq\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.contentColumnType','\"text\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.fieldGroup','\"684cc56c-13ac-45b3-807a-2077cfac261a\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.handle','\"testo\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.instructions','null'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.name','\"Testo\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.searchable','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.availableTransforms','\"\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.availableVolumes','\"\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.columnType','\"text\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.configSelectionMode','\"choose\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.defaultTransform','\"\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.manualConfig','\"\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.purifierConfig','null'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.purifyHtml','true'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.redactorConfig','null'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.removeEmptyTags','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.removeInlineStyles','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.removeNbsp','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.showHtmlButtonForNonAdmins','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.showUnpermittedFiles','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.showUnpermittedVolumes','false'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.settings.uiMode','\"enlarged\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.translationKeyFormat','null'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.translationMethod','\"none\"'),('fields.f095057b-12b7-426e-bba9-77a4e6e2c1ce.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.field','\"e84f8add-70a4-4227-835b-be62710af7e2\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elementCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.fieldUid','\"16f54560-82dd-48ec-80f4-1288baf410fa\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.label','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.required','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.tip','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.uid','\"070ae3fe-6079-479d-b5f3-b765c7a20f69\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.warning','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.0.width','100'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.fieldUid','\"497a8ec3-9f9a-4947-a0b1-b9404c1c59f3\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.label','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.required','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.tip','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.uid','\"5e758ecc-ab92-41be-97a4-563e1adf764f\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.warning','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.elements.1.width','100'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.name','\"Content\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.uid','\"4f5ce121-9e6f-47c7-9786-c0070f0e4f96\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fieldLayouts.f49e7efc-e7fe-416f-ab1c-eb2765b940d0.tabs.0.userCondition','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.columnSuffix','\"mnpawajh\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.contentColumnType','\"text\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.fieldGroup','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.handle','\"testo\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.instructions','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.name','\"testo\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.searchable','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.byteLimit','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.charLimit','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.code','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.columnType','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.initialRows','4'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.multiline','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.placeholder','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.settings.uiMode','\"normal\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.translationKeyFormat','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.translationMethod','\"none\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.16f54560-82dd-48ec-80f4-1288baf410fa.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.columnSuffix','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.contentColumnType','\"string\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.fieldGroup','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.handle','\"entry\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.instructions','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.name','\"entry\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.searchable','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.allowSelfRelations','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.branchLimit','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.localizeRelations','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.maintainHierarchy','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.maxRelations','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.minRelations','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.selectionLabel','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.showSiteMenu','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.sources','\"*\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.targetSiteId','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.validateRelatedElements','false'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.settings.viewMode','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.translationKeyFormat','null'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.translationMethod','\"site\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.fields.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3.type','\"craft\\\\fields\\\\Entries\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.handle','\"blocco\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.name','\"Blocco\"'),('matrixBlockTypes.e679f241-0434-4caa-aab9-a8cb07cc0a72.sortOrder','1'),('meta.__names__.04d63fa5-e717-48bf-b8f8-340293fffda5','\"Test\"'),('meta.__names__.16f54560-82dd-48ec-80f4-1288baf410fa','\"testo\"'),('meta.__names__.218ba258-0fdf-4523-aacc-3b77f78e0b41','\"Related\"'),('meta.__names__.2453ab96-1f4f-4612-ab9b-d1e5203ac208','\"Homepage\"'),('meta.__names__.497a8ec3-9f9a-4947-a0b1-b9404c1c59f3','\"entry\"'),('meta.__names__.684cc56c-13ac-45b3-807a-2077cfac261a','\"Common\"'),('meta.__names__.8cf230db-3044-4cb7-aeb7-ed3578d3485d','\"Categorie\"'),('meta.__names__.943a0c4d-6ca1-44ff-9a54-21837fcee488','\"Default\"'),('meta.__names__.adb5b625-1b31-4da6-81ae-c8f553cdcd9b','\"Default\"'),('meta.__names__.cb3eb1f1-99e6-4d58-9e62-aae04d9497f5','\"Homepage\"'),('meta.__names__.d636c4e4-6378-4522-8367-33f665f4a711','\"Test Docker\"'),('meta.__names__.e679f241-0434-4caa-aab9-a8cb07cc0a72','\"Blocco\"'),('meta.__names__.e84f8add-70a4-4227-835b-be62710af7e2','\"Matrix\"'),('meta.__names__.e8b64a7b-ad2f-426b-ba3c-3cbe058f4746','\"Test Docker\"'),('meta.__names__.f095057b-12b7-426e-bba9-77a4e6e2c1ce','\"Testo\"'),('plugins.element-api.edition','\"standard\"'),('plugins.element-api.enabled','true'),('plugins.element-api.schemaVersion','\"1.0.0\"'),('plugins.feed-me.edition','\"standard\"'),('plugins.feed-me.enabled','true'),('plugins.feed-me.schemaVersion','\"5.1.0.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.defaultPlacement','\"end\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.enableVersioning','false'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.handle','\"test\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.name','\"Test\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.propagationMethod','\"all\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.enabledByDefault','true'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.hasUrls','true'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.template','\"test/_entry\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.uriFormat','\"test/{slug}\"'),('sections.04d63fa5-e717-48bf-b8f8-340293fffda5.type','\"channel\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.defaultPlacement','\"end\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.enableVersioning','false'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.handle','\"homepage\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.name','\"Homepage\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.propagationMethod','\"all\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.enabledByDefault','true'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.hasUrls','true'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.template','\"index.twig\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.uriFormat','\"__home__\"'),('sections.2453ab96-1f4f-4612-ab9b-d1e5203ac208.type','\"single\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.defaultPlacement','\"end\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.enableVersioning','false'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.handle','\"categorie\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.name','\"Categorie\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.propagationMethod','\"all\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.enabledByDefault','true'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.hasUrls','true'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.template','null'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.siteSettings.d636c4e4-6378-4522-8367-33f665f4a711.uriFormat','\"categorie/{slug}\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.structure.maxLevels','null'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.structure.uid','\"122d816c-439f-4ff6-bfa9-bcbb6a4eb862\"'),('sections.8cf230db-3044-4cb7-aeb7-ed3578d3485d.type','\"structure\"'),('siteGroups.e8b64a7b-ad2f-426b-ba3c-3cbe058f4746.name','\"Test Docker\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.enabled','true'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.handle','\"default\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.hasUrls','true'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.language','\"en-US\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.name','\"Test Docker\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.primary','true'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.siteGroup','\"e8b64a7b-ad2f-426b-ba3c-3cbe058f4746\"'),('sites.d636c4e4-6378-4522-8367-33f665f4a711.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Test Docker\"'),('system.schemaVersion','\"4.5.3.0\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (1,5,6,NULL,1,1,'2023-12-21 14:33:29','2023-12-21 14:33:29','2bcfc5c6-53ac-4434-ac02-37e90759456c');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'slug',0,1,' homepage '),(1,'title',0,1,' homepage '),(2,'email',0,1,' michele dellanesta it '),(2,'firstname',0,1,''),(2,'fullname',0,1,''),(2,'lastname',0,1,''),(2,'slug',0,1,''),(2,'username',0,1,' dnadmin '),(3,'slug',0,1,' test entry '),(3,'title',0,1,' test entry '),(6,'slug',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,1,'Categorie','categorie','structure',0,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\"}]','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'8cf230db-3044-4cb7-aeb7-ed3578d3485d'),(2,NULL,'Test','test','channel',0,'all','end',NULL,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'04d63fa5-e717-48bf-b8f8-340293fffda5'),(3,NULL,'Homepage','homepage','single',0,'all','end',NULL,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'2453ab96-1f4f-4612-ab9b-d1e5203ac208');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'categorie/{slug}',NULL,1,'2023-12-21 14:02:10','2023-12-21 14:02:10','583929d3-1fde-4de6-a91e-ba60b983f698'),(2,2,1,1,'test/{slug}','test/_entry',1,'2023-12-21 14:02:10','2023-12-21 14:02:10','6aa7a5f4-9137-4cd0-b6c7-74ee682c4dfc'),(3,3,1,1,'__home__','index.twig',1,'2023-12-21 14:02:10','2023-12-21 14:02:10','da1cf30a-db59-4c34-949a-d8147b139b10');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Test Docker','2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'e8b64a7b-ad2f-426b-ba3c-3cbe058f4746');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'1','Test Docker','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'d636c4e4-6378-4522-8367-33f665f4a711');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2023-12-21 14:02:10','2023-12-21 14:02:10',NULL,'122d816c-439f-4ff6-bfa9-bcbb6a4eb862');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (2,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (2,NULL,1,0,0,0,1,'DNAdmin',NULL,NULL,NULL,'michele@dellanesta.it','$2y$13$qSJduFPT4IbLLgJm9NrWx.OvSAK7okE8V72U9t5x6O45ZNydhrVv6','2023-12-21 14:03:04',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2023-12-21 14:02:10','2023-12-21 14:02:10','2023-12-21 14:03:04');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,2,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-12-21 14:03:04','2023-12-21 14:03:04','20d98a77-7f56-451f-948d-da9dcad302da'),(2,2,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-12-21 14:03:04','2023-12-21 14:03:04','8b8112bf-9ebd-4487-b9a7-0e997ba7fca4'),(3,2,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-12-21 14:03:04','2023-12-21 14:03:04','9dcd3d42-d335-40f5-8744-c08afceed774'),(4,2,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https:\\/\\/craftcms.com\\/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-12-21 14:03:04','2023-12-21 14:03:04','10cb0f05-c783-463a-9ec9-34de3eb6ea78');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-12-21 14:37:46
